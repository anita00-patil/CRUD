﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentSecondAssignment
{
    internal class Program
    {
       

        static void Main(string[] args)
        {
            SqlConnection sqlConnection;
            string connectionString = "Server=BLR1-LHP-N84318\\SQLEXPRESS;Database=Student;Trusted_Connection=True";
            sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();
            Console.WriteLine("Connection created successfully!!");
            bool exit = true;
            while (exit)
            {
                Console.WriteLine("********************************");
                Console.WriteLine("1.Add the Data");
                Console.WriteLine("2.Get the Data");
                Console.WriteLine("3.Get the Data by ID");
                Console.WriteLine("4.Update the Data");
                Console.WriteLine("5.Delete the Data");
                Console.WriteLine("6.Exit");
                Console.WriteLine("Enter an option");
                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:addData(sqlConnection);
                           break;
                    case 2:getData(sqlConnection);
                           break;
                    case 3:getDataById(sqlConnection);
                           break;
                    case 4:updateData(sqlConnection);
                           break;
                    case 5:deleteData(sqlConnection);
                           break;
                    case 6:
                        exit = false;
                        break;

                }
            }


        }
        private static void addData(SqlConnection sqlConnection)
        {
            Console.WriteLine("Enter the StudID:");
            int studid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Name:");
            String name=Console.ReadLine();
            Console.WriteLine("Enter the class:");
            int Class=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Address:");
            string address=Console.ReadLine();

            string insertQuery = "insert into Students(StudID,StudName,Class,Address)values('" + studid + "','" + name + "','" + Class + "','" + address + "')";
            
            SqlCommand insertCommand=new SqlCommand(insertQuery,sqlConnection);
            Console.WriteLine("Enter number of Subjects:");
            int n=int.Parse(Console.ReadLine());
            for(int i=0;i<n;i++)
            {
                //Console.WriteLine("Enter the SubID:");
                //int Sid = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the StudID:");
                int sID = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the SubName:");
                String Sname = Console.ReadLine();
                Console.WriteLine("Enter the ObtMarks:");
                int obtMarks = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the MaxMarks:");
                int maxMarks = int.Parse(Console.ReadLine());

               
                string insertQuery2= "insert into Subject(SubID,studID,SubName,ObtMarks,MaxMarks)values('" + studid + "','" + sID + "','" + Sname + "','" + obtMarks + "','" + maxMarks + "')";
                SqlCommand insertCommand2 = new SqlCommand(insertQuery2, sqlConnection);
                insertCommand2.ExecuteNonQuery();

            }
            insertCommand.ExecuteNonQuery();
            Console.WriteLine("Data inserted Successfully!!");
           


        }
        private static void getData(SqlConnection sqlConnection)
        {
           
            string selectAllQuery = "select * from Students";
            string selectAllQuery2 = "select * from Subject";
            SqlCommand selectAllCommand = new SqlCommand(selectAllQuery, sqlConnection);
            SqlCommand selectAllCommand2 = new SqlCommand(selectAllQuery2, sqlConnection);

            SqlDataReader dr = selectAllCommand.ExecuteReader();
           
            Console.WriteLine();
            Console.WriteLine("StudentId  " + "Name  " + "Address  " + "Standard");
            Console.WriteLine("-----------------------------------------------");
            while (dr.Read())
            {

                Console.WriteLine($" {dr[0]}\t    {dr[1]}    {dr[2]}\t     {dr[3]}");
            }
            dr.Close();
            SqlDataReader dr2 = selectAllCommand2.ExecuteReader();
            Console.WriteLine();
            Console.WriteLine("StudentId  " + "Sub Id  " + "Sub Name  " + "Marks obtained  " + "Max marks");

            Console.WriteLine("-----------------------------------------------------");
            while (dr2.Read())
            {
                Console.WriteLine($" {dr2[0]}         {dr2[1]}         {dr2[2]}         {dr2[3]}\t       {dr2[4]}");
            }
            dr2.Close();
        }
        private static void getDataById(SqlConnection sqlConnection)
        {
            int c2 = 0;
            Console.WriteLine("Enter the id to get the Data:");
            int studid2 = int.Parse(Console.ReadLine());
            string selectQueryId = "select * from Students where StudID=" + studid2;
            string selectQueryId2 = "select * from Subject where StudID=" + studid2;

            SqlCommand selectIdCommand=new SqlCommand(selectQueryId,sqlConnection);
            SqlCommand selectIdCommand2 = new SqlCommand(selectQueryId2, sqlConnection);

            SqlDataReader dr3=selectIdCommand.ExecuteReader();
            if(dr3.Read() == false)
            {
                Console.WriteLine("StudentId Not found Enter the Valid Id");
            }
            else
            {
                dr3.Close();
                SqlDataReader dr4=selectIdCommand.ExecuteReader();
                Console.WriteLine("\tStudID\t" + "\tStudName\t" + "Class\t" + "\tAddress\t");
                Console.WriteLine("----------------------------------------------------------------");
                while(dr4.Read())
                {
                    Console.WriteLine($"\t{dr4[0]}\t  \t{dr4[1]}\t   \t{dr4[2]}\t    \t{dr4[3]}\t");
                }
                dr4.Close();
                SqlDataReader dr5 = selectIdCommand2.ExecuteReader();
                Console.WriteLine();
                Console.WriteLine("\tSubID\t" + "\tStudID\t" + "\tSubName\t" + "\tObtMarks\t" + "MaxMarks\t");
                Console.WriteLine("-------------------------------------------------------------------------------");
                while(dr5.Read())
                {
                    Console.WriteLine($"\t{dr5[0]}\t  \t{dr5[1]}\t   \t{dr5[2]}\t    \t{dr5[3]}\t   \t{dr5[4]}");
                }
                dr5.Close();
            }


        }
        private static void updateData(SqlConnection sqlConnection)
        { 
            int c3 = 0;
            Console.WriteLine("Enter the id to be Updated:");
            
            int studid3 = int.Parse(Console.ReadLine());
            string selectQuery3 = "select *from Students where StudID='"+ studid3 + "'";
            SqlCommand selectCommand2 = new SqlCommand(selectQuery3, sqlConnection);
            SqlDataReader dr6 = selectCommand2.ExecuteReader();
            if (dr6.Read() == false)
            {
                Console.WriteLine("StudentId Not found Enter the Valid Id");
                dr6.Close();
            }
            else
            {
                dr6.Close();
                
                Console.WriteLine("Enter the Name:");
                String nameU = Console.ReadLine();
                Console.WriteLine("Enter the class:");
                int ClassU = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the Address:");
                string addressU = Console.ReadLine();

                Console.WriteLine("Enter the SubID:");
                int SidU = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the SubName:");
                String SnameU = Console.ReadLine();
                Console.WriteLine("Enter the ObtMarks:");
                int obtMarksU = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the MaxMarks:");
                int maxMarksU = int.Parse(Console.ReadLine());

                string UpdateQuery = $"update Students set StudName='"+ nameU +"',Class='"+ClassU+ "',Address='"+addressU+"' WHERE StudID="+ studid3;
                string UpdateQuery2 = $"update Subject set SubID='"+SidU+"',SubName='"+SnameU+"',ObtMarks='"+obtMarksU+"',MaxMarks='"+maxMarksU+"' where id="+ studid3;

                SqlCommand updateCommand = new SqlCommand(UpdateQuery, sqlConnection);
                SqlCommand updateCommand2 = new SqlCommand(UpdateQuery2, sqlConnection);

                updateCommand.ExecuteNonQuery();
                //updateCommand2.ExecuteNonQuery();
                Console.WriteLine("Data is updated Successfully!!");
            }
        }
        private static void deleteData(SqlConnection sqlConnection)
        {
            int c4 = 0;
            Console.WriteLine("Enter the id to be Deleted:");
            int studid4 = int.Parse(Console.ReadLine());
            string deleteQuery = "delete from Students where StudID=" + studid4;
            string deleteQuery2 = "delete from Subject where StudID=" + studid4;
            SqlCommand deleteCommand = new SqlCommand(deleteQuery, sqlConnection);
            SqlCommand deleteCommand2 = new SqlCommand(deleteQuery2, sqlConnection);
            c4 = deleteCommand.ExecuteNonQuery();
            deleteCommand2.ExecuteNonQuery();
            if (c4 == 0)
            {
                Console.WriteLine("ID doesnot exist");
            }
            else
            {
                Console.WriteLine("Data deleted Successfully");
            }
        }        

     
       
    }
}
