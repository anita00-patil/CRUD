﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace StudentData
{
    internal class Program
    {
        static List<Student> studentslist = new List<Student>();
        public class Student
        {
            public string Name { get; set; }
            public int StudId { get; set; }
            public string Address { get; set; }
            public string Class { get; set; }
            public List<string> Subjects { get; set; }
            public List<SubjectScore> Scores { get; set; }

        }
        public class SubjectScore
        {
            public int SubId { get; set; }
            public string SubName { get; set; }
            public int SubMaxMarks { get; set; }
            public int SubMarksObtained { get; set; }
        }

        static void Main(string[] args)
        {
            Student student1 = new Student()
            {
                Name = "Anita",
                StudId = 1,
                Address = "Yadgiri ",
                Class = "A",
                Subjects = new List<string>() { "Kannada", "Hindi", "Eng" },
                Scores = new List<SubjectScore>()
                {
                     new SubjectScore()
                     {
                          SubId = 1,
                          SubName = "Kannada",
                          SubMaxMarks = 100,
                          SubMarksObtained = 86
                     },
                     new SubjectScore()
                     {
                          SubId = 2,
                          SubName = "Hindi  ",
                          SubMaxMarks = 100,
                          SubMarksObtained = 98
                     },
                     new SubjectScore()
                     {
                          SubId = 3,
                          SubName = "Eng",
                          SubMaxMarks = 100,
                          SubMarksObtained = 98
                     }

                }
            };
            studentslist.Add(student1);
            Student student2 = new Student()
            {
                Name = "Shreyas",
                StudId = 2,
                Address = "Banglore",
                Class = "A",
                Subjects = new List<string>() { "Kannada", "Hindi", "Eng" },
                Scores = new List<SubjectScore>()
                {
                     new SubjectScore()
                     {
                          SubId = 1,
                          SubName = "Kannada",
                          SubMaxMarks = 100,
                          SubMarksObtained = 95
                     },
                     new SubjectScore()
                     {
                          SubId = 2,
                          SubName = "Hindi",
                          SubMaxMarks = 100,
                          SubMarksObtained = 81
                     },
                     new SubjectScore()
                     {
                          SubId =3,
                          SubName = "Eng",
                          SubMaxMarks = 100,
                          SubMarksObtained = 81
                     }

                }
            };
            studentslist.Add(student2);
            Student student = new Student();
            bool exit = true;
            while (exit)
            {
                Console.WriteLine("\n----------Menu----------");
                Console.WriteLine("1-Add \n2-Display\n3-DisplayAll\n4-Delete\n5-Update\n6-Exit");
                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        try
                        {
                            var ss = (from stu in studentslist
                                      select stu).LastOrDefault();
                            Console.WriteLine("Enter the Name:");
                            string name = Console.ReadLine();
                            while (!name.All(Char.IsLetter))
                            {
                                Console.WriteLine("Name should contain letter only, Try again..!");
                                name = Console.ReadLine();
                            }
                            int id = ss.StudId + 1;
                            Console.WriteLine("Enter the Address:");
                            string address = Console.ReadLine();
                            while (!address.All(Char.IsLetter))
                            {
                                Console.WriteLine("Address should contain letter only, Try again..!");
                                address = Console.ReadLine();
                            }
                            Console.WriteLine("Enter the Class:");
                            string section = Console.ReadLine();
                            while (!section.All(Char.IsLetter))
                            {
                                Console.WriteLine("Invalid input, Try again..!");
                                section = Console.ReadLine();
                            }
                            Console.WriteLine("Enter the name of subject1:");
                            string sub1 = Console.ReadLine();
                            while (!sub1.All(Char.IsLetter))
                            {
                                Console.WriteLine("Subject name should contain letters only, Try again..!");
                                sub1 = Console.ReadLine();
                            }
                            Console.WriteLine("Enter the name of subject2:");
                            string sub2 = Console.ReadLine();
                            while (!sub2.All(Char.IsLetter))
                            {
                                Console.WriteLine("Subject name should contain letters only, Try again..!");
                                sub2 = Console.ReadLine();
                            }
                            Console.WriteLine("Enter the name of subject3:");
                            string sub3 = Console.ReadLine();
                            while (!sub3.All(Char.IsLetter))
                            {
                                Console.WriteLine("Subject name should contain letters only, Try again..!");
                                sub3 = Console.ReadLine();
                            }
                            Console.WriteLine("Enter the Subject1 Marks Obtained:");
                            int sub1marksObtained = Convert.ToInt32(Console.ReadLine());
                            while (sub1marksObtained > 100)
                            {
                                Console.WriteLine("Marks should be less than 100, Try again..!");
                                sub1marksObtained = Convert.ToInt32(Console.ReadLine());
                            }
                            Console.WriteLine("Enter the Subject2 Marks Obtained:");
                            int sub2marksObtained = Convert.ToInt32(Console.ReadLine());
                            while (sub2marksObtained > 100)
                            {
                                Console.WriteLine("Marks should be less than 100, Try again..!");
                                sub2marksObtained = Convert.ToInt32(Console.ReadLine());
                            }
                            Console.WriteLine("Enter the Subject3 Marks Obtained:");
                            int sub3marksObtained = Convert.ToInt32(Console.ReadLine());
                            while (sub3marksObtained > 100)
                            {
                                Console.WriteLine("Marks should be less than 100, Try again..!");
                                sub3marksObtained = Convert.ToInt32(Console.ReadLine());
                            }
                            Console.WriteLine("Student Data Added successfuly");
                            Console.WriteLine("----------------------------------");
                            student = new Student()
                            {
                                Name = name,
                                StudId = id,
                                Address = address,
                                Class = section,
                                Subjects = new List<string>() { sub1, sub2, sub3 },
                                Scores = new List<SubjectScore>()
                            {
                                new SubjectScore()
                                {
                                    SubId = 1,
                                    SubName = sub1,
                                    SubMaxMarks = 100,
                                    SubMarksObtained = sub1marksObtained
                                },
                                new SubjectScore()
                                {
                                    SubId = 2,
                                    SubName = sub2,
                                    SubMaxMarks = 100,
                                    SubMarksObtained = sub2marksObtained
                                },
                                new SubjectScore()
                                {
                                    SubId = 3,
                                    SubName = sub3,
                                    SubMaxMarks = 100,
                                    SubMarksObtained = sub2marksObtained
                                }


                            }
                            };
                            studentslist.Add(student);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter the id to display:");
                        int studId = Convert.ToInt32(Console.ReadLine());
                        var findid = (from studs in studentslist
                                      where studs.StudId == studId
                                      select studs).Any();
                        if (findid == false)
                        {
                            Console.WriteLine("StudentId Not found Enter the Valid Id");
                            break;
                        }
                        Display(studId);
                        break;
                    case 3:
                        DisplayAll();
                        break;
                    case 4:
                        Console.WriteLine("Enter the id to delete:");
                        int stud = Convert.ToInt32(Console.ReadLine());
                        var finid = (from studs in studentslist
                                     where studs.StudId == stud
                                     select studs).Any();
                        if (finid == false)
                        {
                            Console.WriteLine("StudentId Not found Enter the Valid Id");
                            break;
                        }
                        Delete(stud);
                        break;
                    case 5:
                        Console.WriteLine("Enter the id to update:");
                        int studu = Convert.ToInt32(Console.ReadLine());
                        var finidu = (from studs in studentslist
                                      where studs.StudId == studu
                                      select studs).Any();
                        if (finidu == false)
                        {
                            Console.WriteLine("StudentId Not found Enter the Valid Id");
                            break;
                        }
                        Update(studu);
                        break;


                    case 6:
                        exit = false;
                        break;
                }
            }
            Console.ReadKey();
        }
        public static void DisplayAll()
        {
            if (studentslist.Count == 0)
            {
                Console.WriteLine("No items in the list");
            }
            else
            {

                Console.WriteLine("-------------Student Details--------------\n  ");
                
                foreach (Student stu in studentslist)
                {
                    int subCount = stu.Subjects.Count();
                    int subScoreCount = stu.Scores.Count();
                    Console.WriteLine("\n\nStudentId  Name     Address     Class  \n");
                    Console.Write(+stu.StudId + "        " + stu.Name + "    " + stu.Address + "      " + stu.Class + "      ");
                    
                   
                    Console.WriteLine("\n-------------Subject Details--------------  ");
                    Console.WriteLine(" SubjectId     SubjectName    MaxMarks     MarksObtained     ");
                    foreach (SubjectScore score in stu.Scores)
                    {
                        Console.WriteLine(+score.SubId + "\t\t" + score.SubName + "\t\t" + score.SubMaxMarks + "\t\t" + score.SubMarksObtained);

                    }
                    Console.WriteLine();
                }
            }
        }
        public static void Display(int stuId)
        {
            var students = from stud in studentslist
                           where stud.StudId == stuId
                           select stud;
            Console.WriteLine("-------------Student Details-------------- \n ");
            Console.WriteLine("StudentId  Name     Address     Class ");
            foreach (Student stud in students)
            {
                int subCount = stud.Subjects.Count();
                int subScoreCount = stud.Scores.Count();
                Console.Write("  " + stud.StudId + "         " + stud.Name + "    " + stud.Address + "      " + stud.Class + "      ");
                
                Console.WriteLine("\n-------------Subject Details--------------  ");
                Console.WriteLine(" SubjectId     SubjectName    MaxMarks     MarksObtained     ");
                foreach (SubjectScore score in stud.Scores)
                {
                    Console.Write("        " + score.SubId + "          ");
                    Console.Write(score.SubName + "          ");
                    Console.Write(score.SubMaxMarks + "          ");
                    Console.Write(score.SubMarksObtained);
                    Console.Write("                                                                     ");
                }
            }
        }
        public static void Update(int stuId)
        {
            var student = (from stud in studentslist
                           where stud.StudId == stuId
                           select stud);
            foreach (var students in student)
            {
                Console.WriteLine("Enter the Name:");
                string name = Console.ReadLine();
                while (!name.All(Char.IsLetter))
                {
                    Console.WriteLine("Name should contain letter only, Try again..!");
                    name = Console.ReadLine();
                }
                Console.WriteLine("Enter the Address:");
                string address = Console.ReadLine();
                while (!address.All(Char.IsLetter))
                {
                    Console.WriteLine("Address should contain letter only, Try again..!");
                    address = Console.ReadLine();
                }
                Console.WriteLine("Enter the Class:");
                string section = Console.ReadLine();
                while (!section.All(Char.IsLetter))
                {
                    Console.WriteLine("Invalid input, Try again..!");
                    section = Console.ReadLine();
                }
                Console.WriteLine("Enter the name of subject1:");
                string sub1 = Console.ReadLine();
                while (!sub1.All(Char.IsLetter))
                {
                    Console.WriteLine("Subject name should contain letters only, Try again..!");
                    sub1 = Console.ReadLine();
                }
                Console.WriteLine("Enter the name of subject2:");
                string sub2 = Console.ReadLine();
                while (!sub2.All(Char.IsLetter))
                {
                    Console.WriteLine("Subject name should contain letters only, Try again..!");
                    sub2 = Console.ReadLine();
                }
                Console.WriteLine("Enter the name of subject3:");
                string sub3 = Console.ReadLine();
                while (!sub3.All(Char.IsLetter))
                {
                    Console.WriteLine("Subject name should contain letters only, Try again..!");
                    sub3 = Console.ReadLine();
                }
                Console.WriteLine("Enter the Subject1 Marks Obtained:");
                int sub1marksObtained = Convert.ToInt32(Console.ReadLine());
                while (sub1marksObtained > 100)
                {
                    Console.WriteLine("Marks should be less than 100, Try again..!");
                    sub1marksObtained = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine("Enter the Subject2 Marks Obtained:");
                int sub2marksObtained = Convert.ToInt32(Console.ReadLine());
                while (sub2marksObtained > 100)
                {
                    Console.WriteLine("Marks should be less than 100, Try again..!");
                    sub2marksObtained = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine("Enter the Subject3 Marks Obtained:");
                int sub3marksObtained = Convert.ToInt32(Console.ReadLine());
                while (sub3marksObtained > 100)
                {
                    Console.WriteLine("Marks should be less than 100, Try again..!");
                    sub3marksObtained = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine("Student Data Updated successfuly");
                Console.WriteLine("----------------------------------");
                students.Name = name;
                students.Address = address;
                students.Class = section;
                students.Subjects[0] = sub1;
                students.Subjects[1] = sub2;
                students.Subjects[2] = sub3;

                students.Scores[0].SubMarksObtained = sub1marksObtained;
                students.Scores[1].SubMarksObtained = sub2marksObtained;
                students.Scores[2].SubMarksObtained = sub3marksObtained;

                students.Scores[0].SubName = sub1;
                students.Scores[1].SubName = sub2;
                students.Scores[2].SubName = sub3;

            }

        }
        public static void Delete(int stuId)
        {
            var student = (from stud in studentslist
                           where stud.StudId == stuId
                           select stud);
            foreach (var students in student)
            {
                students.Name = null;
                students.Address = null;
                students.Subjects = null;
                students.Class = null;
                students.StudId = 0;
                students.Scores = null;
            }
            IEnumerable<int> indexes = from stud in studentslist
                                       where stud.StudId == 0
                                       select studentslist.IndexOf(stud);
            studentslist.RemoveAt(indexes.FirstOrDefault());
            Console.WriteLine("Data Deleted successfuly!!!!");
        }
    }

   
}
