﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentWebApi.Models;

namespace StudentWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : Controller
    {
        private readonly WebDbContext _dbContext;
        public StudentController(WebDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        //Get :api/products
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Student>>> GetProducts()
        {
            return await _dbContext.Students.ToListAsync();
        }


        //GET:api/Products/1{ProductId}
        [HttpGet("{id}")]
        public async Task<ActionResult<Student>> GetProductById(int id)
        {
            var student = await _dbContext.Students.FindAsync(id);

            if (student == null)
            {
                return NotFound();
            }
            return student;
        }
        //POST:api/products/
        [HttpPost]
        public async Task<ActionResult<Student>> AddProduct(Student student)
        {
            _dbContext.Students.Add(student);
            await _dbContext.SaveChangesAsync();
            return CreatedAtAction("GetProducts", new { id = student.Id }, student);
        }
    }
}
